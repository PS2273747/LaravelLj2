
<?php $__env->startSection('content'); ?>
<div>
<table class="border-solid border-2 border-indigo-600 ml-40">
    <thead>
        <tr class="border-solid border-2 border-indigo-600">
            <th>Title</th>
            <th class="border-solid border-2 border-indigo-600">Artist</th>

        </tr>
    </thead>
    <tbody>
        <tr class="border-solid border-2 border-indigo-600">
            <td class="border-solid border-2 border-indigo-600"><?php echo e($songs->title); ?></td>
            <td><?php echo e($songs->singer); ?></td>
        </tr>
        <form action= "/details/<?php echo e($songs->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
        <br>
        <form action= "/edit/<?php echo e($songs->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
          
            <button> Edit </button>
        </form>
        </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Summa_College\Leerjaar_2\Laravel\periode_1\Week_4\week4opdr1\resources\views/songs_table/details.blade.php ENDPATH**/ ?>