@extends('layouts.app')
@section('content')
<div class="text-5xl p-4">Welkom</div>
@endsection
