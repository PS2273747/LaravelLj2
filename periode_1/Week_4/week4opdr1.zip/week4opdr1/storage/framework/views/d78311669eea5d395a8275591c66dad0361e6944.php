
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="text-2xl p-4"><a class="text-purple-500 hover:text-purple-800" href="/details/<?php echo e($song->id); ?>"><?php echo e($song->title); ?></a></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Summa_College\Leerjaar_2\Laravel\periode_1\Week_4\week4opdr1\resources\views/songs_table/title.blade.php ENDPATH**/ ?>