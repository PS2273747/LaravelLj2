<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Songs</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>

    <div class="bg-gradient-to-r from-red-400 to-gray-800 text-white text-5xl">
        <ul class="flex p-4">
            <li class="mr-6 flex-auto">
                Songs
            </li>

        </ul>
    </div>
    <ul class="flex text-3xl mt-4 p-4">
    <li class="mr-6">
            <a class="text-blue-500 hover:text-blue-800" href="<?php echo e(('/home')); ?>">Home</a>
        </li>
        <li class="mr-6">
            <a class="text-blue-500 hover:text-blue-800" href="<?php echo e('/index'); ?>">Songs</a>
        </li>
     
        <li class="mr-6">
            <a class="text-blue-500 hover:text-blue-800" href="<?php echo e('/create'); ?>">Create</a>
        </li>

    </ul>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH D:\Summa_College\Leerjaar_2\Laravel\periode_1\Week_4\week4opdr1\resources\views/layouts/app.blade.php ENDPATH**/ ?>